package org.todo.todorails;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TotoRailsApplication {

    public static void main(String[] args) {
        SpringApplication.run(TotoRailsApplication.class, args);
    }

}
